package com.example.przychodnialocal.patient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class PrescriptionsController {

    @FXML
    private AnchorPane contentAnchorPane;

    @FXML
    private TableView<?> prescriptionsTableView;

    @FXML
    private Button returnButton;

    @FXML
    private TextField searchPrescriptionsTextField;


}
