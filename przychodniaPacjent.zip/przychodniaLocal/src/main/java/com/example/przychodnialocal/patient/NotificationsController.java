package com.example.przychodnialocal.patient;

public class NotificationsController {
}
