package com.example.przychodnialocal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

import java.io.IOException;

public class HelloController {
    @FXML
    private BorderPane borderPane;

    @FXML
    private Button btResources;

    @FXML
    private Button filterButton;

    @FXML
    private Button scheduleButton;

    @FXML
    private Button sortButton;

    @FXML
    private Button sortButton1;

    @FXML
    private Button usersButton;

    @FXML
    private Button visitsButton;


}
