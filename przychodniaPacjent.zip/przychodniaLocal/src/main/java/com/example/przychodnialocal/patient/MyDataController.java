package com.example.przychodnialocal.patient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MyDataController {

    @FXML
    private Button editButton;

    @FXML
    void editData(ActionEvent event) {

    }

}
